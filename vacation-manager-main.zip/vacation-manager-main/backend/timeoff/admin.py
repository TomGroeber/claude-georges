from django.contrib import admin
from timeoff.models import TimeOffRequest

# Register your models here.
admin.site.register(TimeOffRequest)