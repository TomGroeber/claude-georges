from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework import status
from rest_framework.permissions import IsAuthenticated
from django.shortcuts import get_object_or_404
from users.models import CustomUser
from .models import TimeOffRequest
from datetime import datetime
from .serializers import TimeOffRequestSerializer, TimeOffRequestApprovalSerializer
from vacation_manager.response_handler import ResponseHandler
from django.db.models import Sum
from datetime import time, date
from django.db.models import Q
from timeoff.models import get_holidays

class TimeOffRequestListCreateView(APIView):
    """
    View to list all time-off requests or create a new one.
    - GET: Admin can view all requests; Employees see their own requests.
    - POST: Employees can create new requests.
    """
    permission_classes = [IsAuthenticated]
    _rh = ResponseHandler()

    def get(self, request):
        today = datetime.now()
        month = int(request.GET.get("month", today.month))
        year = int(request.GET.get("year", today.year))
        all_events = dict(get_holidays(year)).items()

        events = {
                "events": [
                    {"start_date": datetime(event_date.year, event_date.month, event_date.day), "end_date": datetime(event_date.year, event_date.month, event_date.day, 23,59,59), "title": event_name} 
                    for (event_date, event_name) in all_events 
                    if event_date.month == month
                ]}
        
        if request.user.role == 'admin':
            requests = TimeOffRequest.objects.filter(start_date__month=month,
                                                    end_date__month=month,
                                                    start_date__year=year,
                                                    end_date__year=year)
        else:
            requests = TimeOffRequest.objects.filter(user=request.user,
                                                     start_date__month=month,
                                                     end_date__month=month,
                                                     start_date__year=year,
                                                     end_date__year=year)

        requests = requests.order_by('-id')
        serializer = TimeOffRequestSerializer(requests, many=True)
        
        events.update({"users": serializer.data})
        return self._rh.success_response(data=events)

    def post(self, request):

        print(request.user.role)
        if request.user.role == 'admin':
            return self._rh.error_response(message="Not Allowed")
        
        user = request.user
        data = request.data.copy()
        data['user'] = user.id

        serializer = TimeOffRequestSerializer(data=data)
        if serializer.is_valid():
            user = request.user
            start_date = serializer.validated_data['start_date']
            end_date = serializer.validated_data['end_date']

            leave_days = serializer.validated_data['total_days']
            print(leave_days)

            overlapping_requests = TimeOffRequest.objects.filter(
                    user=user,
                    status__in=['approved', 'pending'],
                    start_date__lte=data['end_date'],
                    end_date__gte=data['start_date']
                )
            
            for request in overlapping_requests:
                    if self.time_overlap(start_date, end_date, request):
                        return self._rh.error_response(message="You have already applied for time off during this period.")
            
            used_leaves = TimeOffRequest.objects.filter(user=user).aggregate(Sum('total_days'))['total_days__sum'] or 0
            available_leaves = user.allowed_leaves - used_leaves
            print(available_leaves)

            if available_leaves < leave_days:
                return self._rh.error_response(message="Insufficient Leave Balance")

            serializer.save()
            return self._rh.success_response(data=serializer.data, message="Leave Application has been sent for Approval")
        try:
            return self._rh.error_response(message=serializer.errors['detail'][0])
        except KeyError:
            return self._rh.error_response(data=serializer.errors, message="An Error Occured")
        
    def time_overlap(self, new_start_date, new_end_date, existing_request):
        existing_start_date = existing_request.start_date
        existing_end_date = existing_request.end_date

        if new_start_date < existing_end_date and new_end_date > existing_start_date:
            return True
        return False


class TimeOffRequestDetailView(APIView):
    """
    View to retrieve or delete a specific time-off request.
    - GET: Retrieve the details of a specific request.
    - DELETE: Employees or Admin can delete a request (only if pending).
    """
    permission_classes = [IsAuthenticated]

    def get(self, request, pk):
        time_off_request = get_object_or_404(TimeOffRequest, pk=pk)
        if request.user != time_off_request.user and request.user.role != 'admin':
            return Response({"detail": "Not authorized."}, status=status.HTTP_403_FORBIDDEN)
        serializer = TimeOffRequestSerializer(time_off_request)
        return Response(serializer.data, status=status.HTTP_200_OK)

    def delete(self, request, pk):
        time_off_request = get_object_or_404(TimeOffRequest, pk=pk)
        if time_off_request.status != 'pending':
            return Response(
                {"detail": "Cannot delete a request that is not pending."},
                status=status.HTTP_400_BAD_REQUEST
            )
        if request.user != time_off_request.user and request.user.role != 'admin':
            return Response({"detail": "Not authorized."}, status=status.HTTP_403_FORBIDDEN)
        time_off_request.delete()
        return Response({"detail": "Time-off request deleted."}, status=status.HTTP_204_NO_CONTENT)


class TimeOffApprovalView(APIView):
    """
    View to approve or reject time-off requests (Admin only).
    - PUT: Update the status of a request (approved/rejected).
    """
    permission_classes = [IsAuthenticated]

    def put(self, request, pk):
        if request.user.role != 'admin':
            return Response({"detail": "Not authorized."}, status=status.HTTP_403_FORBIDDEN)
        
        time_off_request = get_object_or_404(TimeOffRequest, pk=pk)
        if time_off_request.status != 'pending':
            return Response(
                {"detail": "Cannot update a request that is not pending."},
                status=status.HTTP_400_BAD_REQUEST
            )

        serializer = TimeOffRequestApprovalSerializer(instance=time_off_request, data=request.data)
        if serializer.is_valid():
            serializer.save()  # Updates the status
            return Response(serializer.data, status=status.HTTP_200_OK)
        
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)
