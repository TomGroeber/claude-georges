from django.urls import path
from .views import (
    TimeOffRequestListCreateView,
    TimeOffRequestDetailView,
    TimeOffApprovalView,
)

urlpatterns = [
    path('', TimeOffRequestListCreateView.as_view(), name='time-off-list-create'),
    path('<int:pk>', TimeOffRequestDetailView.as_view(), name='time-off-detail'),
    path('<int:pk>/approval', TimeOffApprovalView.as_view(), name='time-off-approval'),
]
