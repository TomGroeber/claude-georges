from rest_framework import serializers
from .models import TimeOffRequest
from users.serializers import UserSerializer

class TimeOffRequestSerializer(serializers.ModelSerializer):
    non_field_errors_key = "detail"
    class Meta:
        model = TimeOffRequest
        fields = ['id', 'user', 'start_date', 'end_date', 'reason', 'status', 'created_at']
        read_only_fields = ['status', 'created_at']

    def to_representation(self, obj):
       self.fields['user'] = UserSerializer(obj.user)
       return super().to_representation(obj)
    
    
    def validate(self, data):
        start_date = data.get('start_date')
        end_date = data.get('end_date')

        if not start_date or not end_date:
            raise serializers.ValidationError({
                self.non_field_errors_key: "Both start date and end date are required for the vacation request."
            })

        time_off_request = TimeOffRequest(start_date=start_date, end_date=end_date)

        if time_off_request.is_weekend(start_date) or time_off_request.is_weekend(end_date):
            raise serializers.ValidationError({
                    self.non_field_errors_key: "Request falls on a weekend. Please select a weekday."
                })

        if time_off_request.is_event_day(start_date) or time_off_request.is_event_day(end_date):
            raise serializers.ValidationError({
                    self.non_field_errors_key: "Request falls on an event day. Please select a non-event day."
                })
        
        leave_days = time_off_request.calculate_days()

        data['total_days'] = leave_days

        if leave_days is None:
            raise serializers.ValidationError({
                self.non_field_errors_key: "Please Apply for Time Off in within Working Hours"
            })
        
        elif leave_days < 0.0:
            raise serializers.ValidationError({
                    self.non_field_errors_key: "The end date cannot be earlier than the start date. Please adjust the dates accordingly."
                })
        
        elif leave_days == 0.0:
            raise serializers.ValidationError({
                    self.non_field_errors_key: "The end date cannot be same as start date. Please adjust the dates accordingly."
                })

        return data

class TimeOffRequestApprovalSerializer(serializers.ModelSerializer):
    class Meta:
        model = TimeOffRequest
        fields = ['status']
        extra_kwargs = {
            'status': {'required': True}
        }
