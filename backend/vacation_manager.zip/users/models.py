from django.contrib.auth.models import AbstractUser
from django.db import models

ROLE_CHOICES = [
    ('turner', 'Turner'),
    ('miller', 'Miller'),
    ('welder', 'Welder'),
    ('admin', 'Admin')
]

class CustomUser(AbstractUser):
    # email = models.EmailField(unique=True)
    passport = models.CharField(max_length=50, blank=True, null=True)
    allowed_leaves = models.DecimalField(max_digits=5, decimal_places=3, default=2.7)
    role = models.CharField(max_length=10, choices=ROLE_CHOICES)
    username = models.CharField(max_length=150, null=True, blank=True)
    username = None
    email = models.EmailField(unique=True)

    USERNAME_FIELD = 'email'
    REQUIRED_FIELDS = []

    def __str__(self):
        return self.username

    
class RoleLimits(models.Model):
    role = models.CharField(max_length=10, choices=ROLE_CHOICES, unique=True)
    max_conncurent_off = models.DecimalField(max_digits=4, decimal_places=1, null=False)