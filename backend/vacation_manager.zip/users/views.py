from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework import status, permissions
from users.permissions import IsSiteAdmin
from django.shortcuts import get_object_or_404
from .models import CustomUser, RoleLimits
from django.contrib.auth import authenticate
from .serializers import LimitsViewSerializer, UserCreateSerializer
from rest_framework_simplejwt.tokens import RefreshToken
from vacation_manager.response_handler import ResponseHandler
from djangorestframework_camel_case.parser import CamelCaseJSONParser
from django.db.models import Q


class UserListView(APIView):
    permission_classes = [IsSiteAdmin]  # Admin-only access
    _rh = ResponseHandler()

    def get(self, request):
        page_size = int(request.GET.get("page_size", 5))
        page_number = int(request.GET.get("page_number", 1))
        search_key = request.GET.get("search_key", None)
        users = CustomUser.objects.exclude(id=request.user.id)

        if search_key:
            search_terms = search_key.split()
            if len(search_terms) == 2:
                fname, lname = search_terms
                users = users.filter(Q(first_name__icontains=fname) & Q(last_name__icontains=lname))
            else:
                users = users.filter(Q(first_name__icontains=search_key) | Q(last_name__icontains=search_key))
        else:
            users = users

        users = users.order_by('-id')[(page_number - 1) * page_size : page_number * page_size]
        
        extras = {
            "total_records": users.count()
        }
        
        serializer = UserCreateSerializer(users, many=True)
        return self._rh.success_response(serializer.data, message="Users retrieved successfully", extras=extras)

class UserCreateView(APIView):
    permission_classes = [IsSiteAdmin]
    _rh = ResponseHandler()

    def post(self, request):
        serializer = UserCreateSerializer(data=request.data)
        if serializer.is_valid():
            serializer.save()
            return self._rh.success_response(serializer.data, message="User created successfully")
        return self._rh.error_response(message=serializer.errors)

class SelfDetailView(APIView):
    permission_classes = [permissions.IsAuthenticated]
    _rh = ResponseHandler()

    def get(self, request):
        serializer = UserCreateSerializer(request.user)
        return self._rh.success_response(data=serializer.data, message="User retrieved successfully")

class ChangePasswordView(APIView):
    permission_classes = [IsSiteAdmin]
    _rh = ResponseHandler()    

    def post(self, request):
        old_password = request.data.get("old_password")
        new_password = request.data.get("new_password")
        user = request.user

        if user.check_password(old_password):
            user.set_password(new_password)
            user.save()
            return self._rh.success_response(message="Password Updated Successfully")
        else:
            return self._rh.error_response(message="Current Password is incorrect")


class GetLimitsView(APIView):
    permission_classes = [IsSiteAdmin]
    _rh = ResponseHandler()

    def get(self, request):
        limits = RoleLimits.objects.all()
        serializer = LimitsViewSerializer(limits, many=True)
        return self._rh.success_response(data=serializer.data, message="Fetched Limits Successfully")

    def patch(self, request):
        turner_limit = request.data.get("turner_limit")
        miller_limit = request.data.get("miller_limit")
        welder_limit = request.data.get("welder_limit")

        turner, turner_created = RoleLimits.objects.get_or_create(
            role="turner",
            defaults={"max_conncurent_off": float(turner_limit)}
        )
        miller, miller_created = RoleLimits.objects.get_or_create(
            role="miller",
            defaults={"max_conncurent_off": float(miller_limit)}
        )
        welder, welder_created = RoleLimits.objects.get_or_create(
            role="welder",
            defaults={"max_conncurent_off": float(welder_limit)}
        )


        if not all([turner_created,miller_created,welder_created]):
            turner.max_conncurent_off = float(turner_limit)
            miller.max_conncurent_off = float(miller_limit)
            welder.max_conncurent_off = float(welder_limit)

            turner.save()
            welder.save()
            miller.save()

        return self._rh.success_response(message="Limits Updated Successfully")
    
class UserDetailView(APIView):
    permission_classes = [permissions.IsAuthenticated]
    _rh = ResponseHandler()

    def get(self, request, pk=None):
        if pk:
            user = get_object_or_404(CustomUser, pk=pk)
        else:
            user = get_object_or_404(CustomUser, id=request.user.id)
        serializer = UserCreateSerializer(user)
        return self._rh.success_response(data=serializer.data, message="User retrieved successfully")

    def patch(self, request, pk):
        if request.user.role == "admin":
            user = get_object_or_404(CustomUser, pk=pk)
            serializer = UserCreateSerializer(user, data=request.data, partial=True)
            if serializer.is_valid():
                serializer.save()
                return self._rh.success_response(serializer.data, message="User updated successfully")
            return self._rh.error_response(serializer.errors, message="Failed to update user")
        return self._rh.error_response(message="Not Allowed")

    def delete(self, request, pk):
        if request.user.role == "admin":
            user = get_object_or_404(CustomUser, pk=pk)
            user.delete()
            return self._rh.success_response(message="User deleted successfully")
        return self._rh.error_response(message="Not Allowed")


class LoginView(APIView):
    _rh = ResponseHandler()
    parser_classes = [CamelCaseJSONParser]


    def post(self, request):
        email = request.data.get('email')
        password = request.data.get('password')

        if not email or not password:
            return self._rh.error_response(message="Please provide both email and password")
        
        try:
            user = CustomUser.objects.get(email=email)   

            user = authenticate(email=email, password=password)
            # print("user",user)
            if user is None:
                return self._rh.success_response(None,code=0, message="Invalid Password")

            refresh = RefreshToken.for_user(user)

            role = "admin" if user.is_superuser else getattr(user, 'role', 'user')

            data = {
                'refresh': str(refresh),
                'access': str(refresh.access_token),
                'user_data': {
                                'role': role,
                                'email': user.email,
                                'first_name': user.first_name,
                                'last_name': user.last_name,
                            }
            }
            return self._rh.success_response(data, message="Login successful")

        except CustomUser.DoesNotExist:
            return self._rh.error_response(message="User not exist")
